@extends('layout.users.app')
@section('title')
    Games
@endsection
@section('main')
    <section class="grid p-10 w-full align-center g-10 pc-grid-2 place-center">
        <div style="border:0.1px solid var(--secondary)" class="w-full br-10 bg-secondary-dark p-10 column g-5">
            <img src="{{ asset('casino/banner-3.png') }}" alt="" class="w-full br-10">
            <strong class="desc">Guess The Color</strong>
            <span>Guess the correct color by clicking on boxes/cards and win amazing prizes.</span>
            <button onclick="spa(event,'{{ url('users/games/color') }}')" class="btn-primary-3d w-full clip-5 br-5">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="CurrentColor" xmlns="http://www.w3.org/2000/svg">
<path d="M9.60751 1.51737C10.3776 1.34229 11.1785 1.25 12 1.25C17.9371 1.25 22.75 6.06294 22.75 12C22.75 17.9371 17.9371 22.75 12 22.75C11.1785 22.75 10.3776 22.6577 9.60751 22.4826C9.2036 22.3908 8.95061 21.9889 9.04244 21.585C9.13427 21.1811 9.53614 20.9281 9.94005 21.02C10.6018 21.1704 11.2911 21.25 12 21.25C17.1086 21.25 21.25 17.1086 21.25 12C21.25 6.89137 17.1086 2.75 12 2.75C11.2911 2.75 10.6018 2.8296 9.94005 2.98004C9.53614 3.07187 9.13427 2.81888 9.04244 2.41497C8.95061 2.01106 9.2036 1.60919 9.60751 1.51737Z" fill="CurrentColor"></path>
<path d="M7.31372 3.13198C7.53443 3.4825 7.42919 3.94557 7.07868 4.16627C5.90349 4.90623 4.90623 5.90349 4.16627 7.07868C3.94556 7.42919 3.4825 7.53443 3.13198 7.31372C2.78146 7.09302 2.67623 6.62995 2.89693 6.27944C3.75646 4.91436 4.91436 3.75646 6.27943 2.89693C6.62995 2.67623 7.09302 2.78146 7.31372 3.13198Z" fill="CurrentColor"></path>
<path d="M2.98004 9.94005C3.07187 9.53614 2.81888 9.13427 2.41497 9.04244C2.01106 8.95061 1.60919 9.2036 1.51737 9.60751C1.34229 10.3776 1.25 11.1785 1.25 12C1.25 12.8215 1.34229 13.6224 1.51737 14.3925C1.60919 14.7964 2.01106 15.0494 2.41497 14.9576C2.81888 14.8657 3.07187 14.4639 2.98004 14.06C2.8296 13.3982 2.75 12.7089 2.75 12C2.75 11.2911 2.8296 10.6018 2.98004 9.94005Z" fill="CurrentColor"></path>
<path d="M3.13198 16.6863C3.4825 16.4656 3.94557 16.5708 4.16627 16.9213C4.90623 18.0965 5.90349 19.0938 7.07868 19.8337C7.42919 20.0544 7.53443 20.5175 7.31372 20.868C7.09302 21.2185 6.62995 21.3238 6.27944 21.1031C4.91436 20.2435 3.75646 19.0856 2.89693 17.7206C2.67623 17.37 2.78146 16.907 3.13198 16.6863Z" fill="CurrentColor"></path>
<path d="M15.4137 10.941C16.1954 11.4026 16.1954 12.5974 15.4137 13.059L10.6935 15.8458C9.93371 16.2944 9 15.7105 9 14.7868V9.21316C9 8.28947 9.93371 7.70561 10.6935 8.15419L15.4137 10.941Z" fill="CurrentColor"></path>
</svg>

             <span>   Play Now</span></button>
        </div>
         <div style="border:0.1px solid var(--secondary)" class="w-full br-10 bg-secondary-dark p-10 column g-5">
            <img src="{{ asset('casino/banner-1.png') }}" alt="" class="w-full br-10">
            <strong class="desc">Roulette</strong>
            <span>Roll the wheel and win amazing rewards up to {!! Currency(Auth::guard('users')->user()->id) !!}5,0000</span>
            <button onclick="spa(event,'{{ url('users/games/roulette') }}')" class="btn-primary-3d disabled w-full clip-5 br-5">
               

             <span>Coming Soon</span></button>
        </div>
    </section>
@endsection