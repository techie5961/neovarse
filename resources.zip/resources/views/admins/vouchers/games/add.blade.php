@extends('layout.admins.app')
@section('title')
   Add Voucher
@endsection
@section('main')
     <section class="w-full column p-10 g-10">
        <form action="{{ url('admins/post/create/voucher/process') }}"  method="POST" onsubmit="PostRequest(event,this,MyFunc.Added)" class="w-full bg-white br-10 box-shadow p-10 column g-5">
            <input type="hidden" name="_token" value="{{ @csrf_token() }}" class="input">
            <div class="row w-full align-center g-5">
             <div class="c-secondary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="CurrentColor" xmlns="http://www.w3.org/2000/svg">
<path d="M12.7499 18.968C13.1812 18.857 13.4999 18.4655 13.4999 17.9996V17.2733C13.4999 17.1099 13.3953 16.9649 13.2403 16.9132C12.4351 16.6448 11.5646 16.6448 10.7594 16.9132C10.6044 16.9649 10.4999 17.1099 10.4999 17.2733V17.9996C10.4999 18.4655 10.8186 18.857 11.2499 18.968V22.25C11.2499 22.6642 11.5856 23 11.9999 23C12.4141 23 12.7499 22.6642 12.7499 22.25V18.968Z" fill="CurrentColor"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M10.6669 5.13443L10.165 4.77922C9.44862 4.27225 8.59264 4 7.71504 4H7.10257C6.69838 4 6.29009 4.02549 5.90915 4.16059C3.52645 5.00566 1.88749 8.09504 2.00604 15.1026C2.02992 16.5145 2.3603 18.075 3.63423 18.6842C4.03121 18.8741 4.49667 19 5.02671 19C5.66273 19 6.1678 18.8187 6.55763 18.5632C6.96641 18.2953 7.32633 17.9471 7.68612 17.599C8.13071 17.1688 8.57511 16.7389 9.11125 16.4609C9.69519 16.1581 10.3434 16 11.0011 16H12.9989C13.6566 16 14.3048 16.1581 14.8888 16.4609C15.4249 16.7389 15.8693 17.1688 16.3139 17.599C16.6737 17.9471 17.0336 18.2953 17.4424 18.5632C17.8322 18.8187 18.3373 19 18.9733 19C19.5033 19 19.9688 18.8741 20.3658 18.6842C21.6397 18.075 21.9701 16.5145 21.994 15.1026C22.1125 8.09503 20.4735 5.00566 18.0908 4.16059C17.7099 4.02549 17.3016 4 16.8974 4H16.2849C15.4074 4 14.5514 4.27225 13.8351 4.77922L13.3332 5.13441C12.9434 5.41029 12.4776 5.55844 12 5.55844C11.5225 5.55844 11.0567 5.41029 10.6669 5.13443ZM16.75 8C17.1642 8 17.5 8.33579 17.5 8.75C17.5 9.16421 17.1642 9.5 16.75 9.5C16.3358 9.5 16 9.16421 16 8.75C16 8.33579 16.3358 8 16.75 8ZM7.5 8.25C7.91421 8.25 8.25 8.58579 8.25 9V9.75H9C9.41421 9.75 9.75 10.0858 9.75 10.5C9.75 10.9142 9.41421 11.25 9 11.25H8.25V12C8.25 12.4142 7.91421 12.75 7.5 12.75C7.08579 12.75 6.75 12.4142 6.75 12V11.25H6C5.58579 11.25 5.25 10.9142 5.25 10.5C5.25 10.0858 5.58579 9.75 6 9.75H6.75V9C6.75 8.58579 7.08579 8.25 7.5 8.25ZM19 10.25C19 10.6642 18.6642 11 18.25 11C17.8358 11 17.5 10.6642 17.5 10.25C17.5 9.83579 17.8358 9.5 18.25 9.5C18.6642 9.5 19 9.83579 19 10.25ZM15.25 11C15.6642 11 16 10.6642 16 10.25C16 9.83579 15.6642 9.5 15.25 9.5C14.8358 9.5 14.5 9.83579 14.5 10.25C14.5 10.6642 14.8358 11 15.25 11ZM17.5 11.75C17.5 11.3358 17.1642 11 16.75 11C16.3358 11 16 11.3358 16 11.75C16 12.1642 16.3358 12.5 16.75 12.5C17.1642 12.5 17.5 12.1642 17.5 11.75Z" fill="CurrentColor"></path>
</svg>

                </div>  
                  <strong class="desc c-bg-secondary">Create New Games Voucher</strong>
            </div>
            <hr>
            <label for="">How many Vouchers</label>
             <div class="cont w-full h-50 border-1 border-color-silver bg-dim br-10">
                <input name="amount" value="1" placeholder="How many codes do you want to generate" type="number" class="inp no-border input w-full h-full br-10 bg-transparent required">
             </div>
            <label for="" class="m-top-5">Select Vendor</label>
            <div class="cont w-full h-50 border-1 border-color-silver bg-dim br-10">
               <select class="inp no-border input w-full h-full br-10 bg-transparent required" name="vendor_id" id="">
                <option value="" selected disabled>Choose Vendor</option>
                <option value="0">Non Vendor</option>
                @if (!$vendors->isEmpty())
                @foreach ($vendors as $data)
                    <option value="{{ $data->id }}">{{ $data->username ?? 'null' }}</option>
                @endforeach
                @endif
               </select>
            </div>
           <label for="">Voucher Value(&#8358;)</label>
             <div class="cont w-full h-50 border-1 border-color-silver bg-dim br-10">
           <input type="number" placeholder="e.g 3000" class="inp no-border input w-full h-full br-10 bg-transparent required" name="value">
             </div>
            <button class="post bg-secondary secondary-text m-top-20 m-bottom-20 w-full"><span>Create Voucher</span></button>
               <div class="w-full g-5 br-10 bg-green-transparent p-10 row align-center">
                <svg class="min-w-20 min-h-20" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="var(--green)" viewBox="0 0 256 256"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm-4,48a12,12,0,1,1-12,12A12,12,0,0,1,124,72Zm12,112a16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40a8,8,0,0,1,0,16Z"></path></svg>
                <span class="c-green font-libertinus-sans">Note that the voucher code is internally generated automatically on submission and is based on the vendor and value entered,upon redemption by a user,his or her games wallet would be creditted the value of the voucher inputted.</span>
               </div>
        </form>
    </section>
@endsection
@section('js')
    <script class="js">
        window.MyFunc = {
            Added : function(response){
                let data=JSON.parse(response);
                if(data.status == 'success'){
                    window.location.href=data.url;
                }
            }
        }
      
    </script>
@endsection